EXAMPLES = {
    "Review 1": "The iPhone 14 Pro is amazing. I'd give it 5 stars. The camera and battery life are outstanding.",
    "Review 2": "I bought a Dell XPS laptop, rating 4/5. It's lightweight, has a sharp display, but the fan is noisy."
}
