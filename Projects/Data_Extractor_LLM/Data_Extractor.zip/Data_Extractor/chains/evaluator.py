from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from config.settings import OPENAI_API_KEY, MODEL_NAME

def get_evaluator_chain():
    llm = ChatOpenAI(model=MODEL_NAME, temperature=0, api_key=OPENAI_API_KEY)

    eval_prompt = ChatPromptTemplate.from_messages([
        ("system", "You are an evaluator. Your task is to judge the quality of extracted structured data."),
        ("user", 
        "Here is the original text:\n\n{input_text}\n\n"
        "Here is the extracted data:\n\n{extracted_data}\n\n"
        "Evaluate:\n"
        "- Accuracy: Does the extracted data match the original text?\n"
        "- Completeness: Are all key details captured?\n"
        "- Relevance: Is the extracted data useful?\n\n"
        "Give a JSON response with fields: accuracy_score (1-5), completeness_score (1-5), relevance_score (1-5), justification (string).")
    ])

    return eval_prompt | llm
