from langchain_openai import ChatOpenAI
from langchain.prompts import ChatPromptTemplate
from schemas.product_schema import parser, ProductReview
from config.settings import OPENAI_API_KEY, MODEL_NAME

def get_extractor_chain():
    llm = ChatOpenAI(model=MODEL_NAME, temperature=0, api_key=OPENAI_API_KEY)

    prompt = ChatPromptTemplate.from_messages([
        ("system", "You are a data extraction assistant."),
        ("user", "{input_text}\n\nFormat:\n{format_instructions}")
    ])

    chain = prompt | llm | parser
    return chain, parser, ProductReview
