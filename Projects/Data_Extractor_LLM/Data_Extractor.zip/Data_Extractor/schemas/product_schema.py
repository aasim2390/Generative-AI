from pydantic import BaseModel, Field
from typing import List
from langchain.output_parsers import PydanticOutputParser

class ProductReview(BaseModel):
    product_name: str = Field(..., description="The name of the product being reviewed")
    rating: str = Field(..., description="The product rating, e.g., 4/5 or 5 stars")
    key_features: List[str] = Field(..., description="List of important product features")
    summary: str = Field(..., description="A short summary of the product review")

# Create parser from schema
parser = PydanticOutputParser(pydantic_object=ProductReview)
