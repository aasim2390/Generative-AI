import json

def to_json_download(data, filename="extracted_data.json"):
    if hasattr(data, "model_dump"):  # Pydantic v2
        data = data.model_dump()
    elif hasattr(data, "dict"):      # Pydantic v1 fallback
        data = data.dict()
    return json.dumps(data, indent=2), filename
